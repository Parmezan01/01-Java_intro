package stringcalculator;

import org.junit.Assert;
import org.junit.Test;

public class StringCalculatorTest {
    @Test
    public void testIfClassExist (){
        Assert.assertNotNull(new StringCalculator());
    }

    @Test
    public void testAdd() {
        StringCalculator stringCalculator = new StringCalculator();
        Assert.assertEquals(0, stringCalculator.add(""));
    }

    @Test
    public void testAddOneNumber() {
        StringCalculator stringCalculator = new StringCalculator();
        Assert.assertEquals(2, stringCalculator.add("2"));
        Assert.assertEquals(11, stringCalculator.add("11"));
    }

    @Test
    public void testAddTwoNumber() {
        StringCalculator stringCalculator = new StringCalculator();
        Assert.assertEquals(3,stringCalculator.add("1,2"));
        Assert.assertEquals(4,stringCalculator.add("2,2"));
    }

    @Test
    public void testAddAnyNumber() {
        StringCalculator stringCalculator = new StringCalculator();
        Assert.assertEquals(6,stringCalculator.add("1,2,3"));
        Assert.assertEquals(13,stringCalculator.add("1,2,5,5"));
    }

    @Test
    public void testAddAnyNumberWithNewLine() {
        StringCalculator stringCalculator = new StringCalculator();
        Assert.assertEquals(6,stringCalculator.add("1,2\n3"));
        Assert.assertEquals(13,stringCalculator.add("1,2\n5\n5"));
    }

    @Test
    public void testAddAnyNumberWithDiffDelemiter() {
        StringCalculator stringCalculator = new StringCalculator();
        Assert.assertEquals(3,stringCalculator.add("//;\n1;2"));
        Assert.assertEquals(7,stringCalculator.add("//f\n1f2f4"));
    }

    @Test (expected = RuntimeException.class)
    public void testAddNegativeNumber (){
        StringCalculator stringCalculator = new StringCalculator();
        stringCalculator.add("-1");
    }

    @Test
    public void testAddwithBigNumber() {
        StringCalculator stringCalculator = new StringCalculator();
        Assert.assertEquals(2,stringCalculator.add("//;\n1001;2"));
        Assert.assertEquals(1000,stringCalculator.add("//f\n100f200f700"));
    }

    @Test
    public void testAddAnyNumberWithLongerDiffDelemiter() {
        StringCalculator stringCalculator = new StringCalculator();
        Assert.assertEquals(3,stringCalculator.add("//[tt]\n1tt2"));
        Assert.assertEquals(7,stringCalculator.add("//[fff]\n1fff2fff4"));
    }

    @Test
    public void testAddAnyNumberWithMultipleDiffDelemiter() {
        StringCalculator stringCalculator = new StringCalculator();
        Assert.assertEquals(6,stringCalculator.add("//[*][%]\n1*2%3"));
        Assert.assertEquals(7,stringCalculator.add("//[fff][g]\n1fff2g4"));
    }
}
