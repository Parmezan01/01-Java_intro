package stringcalculator;

public class StringCalculator{

    public int add (String numbers) throws RuntimeException {
        int result = 0;
        if(numbers !="") {
            String delimiter =",|\n";
            if (numbers.charAt(0) == '/'){
                if (numbers.length()>2 && numbers.charAt(2) == '['){
                    boolean reachedEndOfLine = false;
                    int delimiterStart =2;
                    while (!reachedEndOfLine) {
                        int delimiterEnd = numbers.indexOf(']');
                        delimiter += "|" + numbers.substring(delimiterStart+1, delimiterEnd);
                        if (numbers.charAt(delimiterEnd+1) == '\n') {
                            numbers = numbers.substring(delimiterEnd + 2, numbers.length());
                            reachedEndOfLine = true;
                        } else {
                            delimiterStart = delimiterEnd+1;
                            numbers = numbers.substring(delimiterStart, numbers.length());
                        }
                    }
                } else {
                    delimiter += "|"+numbers.charAt(2);
                    numbers = numbers.substring(4, numbers.length());
                }
            }
            String[] extractedNumbersString = numbers.split(delimiter);
            for (int i=0; i<extractedNumbersString.length; i++){
                int num = Integer.parseInt(extractedNumbersString[i]);
                if(num<0){
                    throw new RuntimeException();
                }
                if(num<=1000){
                    result+= num;
                }
            }
        }

        return result;
    }
}
