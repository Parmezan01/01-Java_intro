package fizzbuzz;

public class FizzBuzz {
}
