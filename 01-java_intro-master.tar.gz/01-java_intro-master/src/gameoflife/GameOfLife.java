package gameoflife;

public class GameOfLife {

}
