package ChapterI;

import java.util.ArrayList;

public class AlhalmazString {

    public static void main(String[] args) {
        int[] halmaz = {1, 2, 3,4,5};
        int index =1;
        ArrayList<String> alhalmaz = new ArrayList<>();
        boolean halmazVege = false;
        alhalmaz.add("");
        for (int i = 0; i < halmaz.length; i++) {
            ArrayList<String> temp = new ArrayList<>(alhalmaz);
            if (i == (halmaz.length-1)){
                halmazVege = true;
            }
            for (String s:temp) {
                s += Integer.toString(halmaz[i]);
                if (!halmazVege){
                    s += ",";
                }
                alhalmaz.add(s);
            }

        }
        for (String s:alhalmaz) {
            System.out.println(index + ".alhalmaz = " + s);
            index++;
        }

    }

}
