package ChapterI;

public class AlhalmazBinary {
    public static void main(String[] args) {

        int[] halmaz = {1, 2, 3,4};
        int sorszam = 1;
        int n = halmaz.length;
        String[] binaris = new String[(int)Math.pow(2,n)];
        String binSize = "%" + n + "s";
        for (int i = 0; i < (Math.pow(2,n)); i++) {
            binaris[i] = String.format(binSize, Integer.toBinaryString(i)).replace(" ", "0");
        }
        for (String bin : binaris){
            System.out.print(sorszam + ". elem =");
            for (int i = 0; i < bin.length(); i++) {
                if (bin.charAt(i) == '1')
                    System.out.print(halmaz[i] + ", ");
            }
            System.out.println();
            sorszam++;
        }
    }
}
