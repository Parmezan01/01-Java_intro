﻿# Introduction to Java and Development Tools

## Objectives

- Get to know each other
- Impro games
- Evaluate coding skills (Google forms test)
- Get to know the development tools (IDEA, git)
- Introduce Java SE: Strings, arrays, methods, exception handling
- Practice Gitlab basics (fork, clone, commit/push)
- Practice pair-programming, TDD and JUnit

## Main Content

### Preparation: Setting up Slack and Chrome

1. Install Slack desktop client
- Linux: http://sourcedigit.com/20087-install-slack-messaging-app-on-ubuntu-16-04/
- Windows: https://slack.com/downloads/windows
2. Install Chrome 
- Linux: https://www.linuxbabe.com/ubuntu/install-google-chrome-ubuntu-16-04-lts
and follow instructions under 'Install Google Chrome on Ubuntu 16.04 the Graphical Way' section
- Windows: https://www.google.com/chrome/browser/desktop/

> ### &#128161; Note: Using Slack
> 
>  Using slack channels: 
>    - '#exercises' : everything that relates to exercises
>    - '#homework' : homework related things
>    - '#general' : main communication from Progmasters, any course related info. 
>    - '#random' : anything else, e.g.: where to go to have lunch, funny things, etc.
>    - '#questions' : all questions related to the course material 

### Preparation: Installing JDK

- Windows
  - Download Oracle JDK 8 (not JDK9!) from http://www.oracle.com/technetwork/java/javase/downloads/jdk8-downloads-2133151.html
  - Run .exe to install
- Linux
  - **We are going to use Oracle JDK!**
  - Open a terminal and enter these commands:
  ```
  sudo add-apt-repository ppa:webupd8team/java
  sudo apt-get update
  sudo apt-get install oracle-java8-installer
  ```
  - Reference: https://www.digitalocean.com/community/tutorials/how-to-install-java-with-apt-get-on-ubuntu-16-04
   

### Preparation: Setting up IDEA

- Install the **Ultimate** version of IntelliJ IDEA: https://www.jetbrains.com/idea/download/#section=windows

We are using a license server to obtain licenses, you need to connect at least once every 2 days to the server!
 - License setup
   - From the menu: Help/Register...
   - License server: http://randy.qtc-kft.com:8092 and then click Register
 - File/Other Settings/Default settings: 
   - Build -> Build Tools -> Compiler -> Java compiler -> Default Java byte code version: 1.8 

### Exercise: Hackerrank

- Prep test: https://docs.google.com/forms/d/e/1FAIpQLSc9aANTy9AlczG2oqqjAlI5p_e1ebFPUK4T3yn2U6mqz-otAw/viewform?usp=sf_link
- work on Preparation test contest challenges - https://www.hackerrank.com/contests/progmasters-assessment-january-2018/challenges

1 ........................................ 1
	
### Exercise: Command Line Tools

1. Open a text editor on your machine and create a simple class, call it HelloWorld.java
2. Save the file and make sure that the name of your class is the same as the filename (e.g. HelloWorld.java file contains a public class called HelloWord)
3. Open a command prompt/terminal on your machine
4. Check whether the java executable is available on your path (meaning if you open a terminal you can run the command 'java')
 - if not, then please set the PATH variable using this description: https://docs.oracle.com/javase/tutorial/essential/environment/paths.html
5. In the terminal window type: 
```
javac HelloWorld.java
```
 - it will turn your code into bytecode that can be executed now by the JVM (Java Virtual Machine)
6. Run the code with the following command:
```
java HelloWorld
```

7. Before we go on with the next exercise, please read this tutorial: https://docs.oracle.com/javase/tutorial/deployment/jar/basicsindex.html
   (optionally read the full tutorial: https://docs.oracle.com/javase/tutorial/deployment/jar/)

8. Create a JAR file with this command: 
```
jar cf hello.jar HelloWorld.class
```
and then try to run the application packaged as a JAR file:
```
java -jar hello.jar
```

Most probably it won't run, you'll get a 'no main manifest attribute...' message, which means the JAR file
itself doesn't know which class it should run/execute.
 
9. Let's try to set the application's entry point! For that you'll need to modify the default manifest file, which can be found
in the jar file under META-INF/MANIFEST.MF.
You can do it manually, by editing the manifest file and adding a Main-Class: HelloWorld.class line at the end, 
or use this command:
```
jar ufe hello.jar HelloWorld
```

10. Try to run the jar file again (now with the main class set in the manifest):
```
java -jar hello.jar
```

> ### &#128161; Note: Important IDEA Hotkeys and Basic Refactoring
> 
> Rewrite the HelloWorld class in IDEA and try out the following features.
>
> Auto import - Alt + Enter
> Code completion - Ctrl + Space  
> Documentation lookup - Ctrl + Q  
> Reformat code - Ctrl + Alt + L  
> Delete line - Ctrl + Y  
> 
> Find - Ctrl + F  
> Find in path - Ctrl + Shift + F  
> 
> Go to class - Ctrl + N  
> Go to file - Ctrl + Shift + N  
> 
> Rename - Shift + F6
> Generate source (e.g. Constructor) - Alt + Insert
	
### Preparation: Setting up Git

1. Install Git
- Linux: 
```
sudo apt-get install git
```
- Windows: https://git-scm.com/download/win
	
### Training: Java basics

- JAVA SE basics - https://my.pcloud.com/publink/show?code=XZqamgZUyhiQ7SxiKRdGw6HVWjqJzyB7phy
- Pair programming - https://my.pcloud.com/publink/show?code=XZrOugZ3BpADvFQAx8uYWeyrgGuqY9eTgDV
- http://butunclebob.com/ArticleS.UncleBob.TheThreeRulesOfTdd 
	
### Preparation: Using GitLab

First of all, install command line git client to your computer (IDEA needs this):
https://www.atlassian.com/git/tutorials/install-git

Then set the path to the executable in IDEA->File->Settings->VersionControl->Git
(In Linux, git will be already in your PATH variable, in windows, you have to
use absolute path)

Login to Progmasters Gitlab server here:
http://progmasters-gitlab.westeurope.cloudapp.azure.com/

For the exercises fork and clone this repository:
**http://progmasters-gitlab.westeurope.cloudapp.azure.com/modular-tm/01-java_intro**

What does fork mean? A fork is a copy of a repository. Forking a repository
allows you to freely experiment with changes without affecting the original
project. A fork of a repository is considered a new project that will not be
kept in sync with the original code.

How? Visit the above URL, and then click on the 'Fork' button in the middle of
the page.

What does clone mean? A clone is another copy but with significant differences
from a fork. First, a clone is created on your machine, not on Gitlab.
Secondly, a clone is supposed to kept in sync with the original repository.
It is actually your working copy of the project, in which you make your own
changes that will be pushed back to the original repo. Also, you can
periodically update this working copy by pulling recent updates from the
original repo that another developers have made since you cloned.
 
How? In IDEA, under VCS/Checkout from Version Control/Git enter the above URL,
and specify the directory where you would like to place the project.
After that simply click on the Next buttons.

To figure out what to do, if IDEA doesn't recognise the Java project check the
Troubleshooting section.



### Preparation: Using Bookmarks

- keep your links organized using browser's bookmarks 

### Workshop: Adding External Library in IDEA
 
1. Open File/Project structure (from menu)
2. Under Libraries click on the green + sign and then select 'From Maven...'
3. Here you can download libraries form external sources and add them to your project
4. Enter 'junit:junit:4.12', click on search icon and then click OK

The selected libraries will be added to the project. You can view them under File/Project structure/Libraries and 
in the Project view in IDEA (left hand side) under External Libraries as well.

> #### &#128161; Note: Troubleshooting
> 
> What to do if IDEA failed to create a Java project after pulling sources from a repository? You need to do
> several tasks manually:
>  - set project's SDK and java version (File -> Project Structure -> Project)
>  - point to project's src and test folders (File -> Project Structure -> Module, sources tab, click the folder then click src or test)
>  - create project compiler output folder (Right click to parent folder, create a folder named 'out')
>  - set the above folder as project output folder  using absolute (!) path (File -> Project Structure -> Project)
	
### Workshop: TDD Kata	

- FizzBuzz - https://technologyconversations.com/2014/03/12/java-tutorial-through-katas-fizz-buzz-easy/

Look at the description (FizzBuzz_rules.md) in the forked repository for this module.
	
### Exercise: Practice TDD

- TDD - Calculator - http://osherove.com/tdd-kata-1/
- practice exercises in tdd package  
	
> ### &#128161; Note: Idea Tricks
>
>  - Autoscroll from source
>  - Showing Toolbar, Tool buttons
>  - Open/close side bars: ctrl+1, ctrl+2 ...
>  - Quick open class: ctrl+n
>  - Search everywhere: double shift
>  - Ctrl+Shift+A: quick search function, e.g.: Split window vertically
>  - Help/Keymap reference
>  - 42 IntelliJ IDEA Tips and Tricks: https://www.youtube.com/watch?v=eq3KiAH4IBI
	
### Exercise: Methods

- Use this repository: **http://progmasters-gitlab.westeurope.cloudapp.azure.com/modular-tm/01-java_intro**
- Solve exercises:
  - BasicCalculator.java in calc package

## Material Review
- javac
- java
- notepad
- IDEA:
  - hotkeys
  - code formatting
  - basic refactoring: rename
  - toolbar, toolbox
  - module settings, library import, test-source folder
- JAVA SE:
  - variables
  - datatypes
  - operators
  - control statements
  - arrays
  - methods
  - memory handling: stack vs heap, references  
  - method overloading
  - arrays, arraylist
  - naming, code conventions
- Pair programming
  - basic ideas
- TDD (Test Driven Development)
  - 3 rules 
- git basic workflow
  - commit
  - push
  - pull
  - fork   
- JUnit
  - @Test annotation
  - running test against code
  - test naming conventions (class name ends with 'Test' or 'Tests', method starts with 'test')

## See also

- Prep test - https://docs.google.com/forms/d/e/1FAIpQLSc9aANTy9AlczG2oqqjAlI5p_e1ebFPUK4T3yn2U6mqz-otAw/viewform?usp=sf_link
- Optional exercises:
  - https://www.hackerearth.com/practice/data-structures/stacks/basics-of-stacks/practice-problems/algorithm/monk-and-philosophers-stone/
  - https://www.hackerearth.com/practice/data-structures/stacks/basics-of-stacks/practice-problems/algorithm/signal-range/
  - https://www.hackerearth.com/practice/data-structures/arrays/multi-dimensional/practice-problems/algorithm/the-wealthy-landlord/
  - https://www.hackerearth.com/practice/algorithms/searching/linear-search/practice-problems/algorithm/repeated-k-times/
  - https://www.hackerearth.com/practice/algorithms/string-algorithm/basics-of-string-manipulation/tutorial/
  - https://www.hackerearth.com/practice/algorithms/string-algorithm/basics-of-string-manipulation/practice-problems/algorithm/palindromes-3/
  - https://www.hackerearth.com/practice/algorithms/string-algorithm/basics-of-string-manipulation/practice-problems/algorithm/short-name/
  - https://www.hackerearth.com/practice/algorithms/string-algorithm/string-searching/practice-problems/algorithm/solitary-string/
- http://www.itcsolutions.eu/2011/02/06/tutorial-java-8-understand-stack-and-heap/
- http://stackoverflow.com/questions/79923/what-and-where-are-the-stack-and-heap
- Java Stack + Heap and Reference & Instance Variables - https://www.youtube.com/watch?v=UcPuWY0wn3w
- Java Tutorial - Stack and Heap: Memory Management - https://www.youtube.com/watch?v=g67agnEPmnA
- The three rules of TDD:
  - http://blog.cleancoder.com/uncle-bob/2014/12/17/TheCyclesOfTDD.html  

## Homework

- IDEA license activation from home
- Clean code - Foreword, Introduction, Chapter 1-2
  - magyarul: https://my.pcloud.com/publink/show?code=XZOVfgZDDxti9o4aF4eISL2p5xQ4RaewsIy
  - angolul: https://my.pcloud.com/publink/show?code=XZazDgZMeElEnsEOby5RIyNwXbwqkTFwd7X
- Clean code - Chapter 3: 
   - Függvények - magyarul: https://my.pcloud.com/publink/show?code=XZq6XNZzW8Q4nzAJohWTU2xz5zNj7WBVuX7
   - Functions - angolul: https://my.pcloud.com/publink/show?code=XZazDgZMeElEnsEOby5RIyNwXbwqkTFwd7X
- Thoughts or questions about the topic in: https://goo.gl/forms/WZzPYUuGM7FTm9NR2

 
## License 

Copyright © Progmasters (QTC Kft.), 2016-2017.
All rights reserved. No part or the whole of this Teaching Material (TM) may be reproduced, copied, distributed, publicly performed, disseminated to the public, adapted or transmitted in any form or by any means, including photocopying, recording, or other electronic or mechanical methods, without the prior written permission of QTC Kft. This TM may only be used for the purposes of teaching exclusively by QTC Kft. and studying exclusively by QTC Kft.’s students and for no other purposes by any parties other than QTC Kft.
This TM shall be kept confidential and shall not be made public or made available or disclosed to any unauthorized person.
Any dispute or claim arising out of the breach of these provisions shall be governed by and construed in accordance with the laws of Hungary. 
 